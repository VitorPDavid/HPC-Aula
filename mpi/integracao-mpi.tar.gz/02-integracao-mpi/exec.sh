#!/bin/bash
#Execute aqui pelo script.
#Parâmetros
#  ./integral 0.001
#               |-> valor do h ou dx

time ./integral 0.001
